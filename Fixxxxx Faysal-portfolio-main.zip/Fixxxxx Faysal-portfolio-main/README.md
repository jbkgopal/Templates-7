# Complete Responsive Personal Portfolio Website using HTML, CSS & JavaScript

## All Section of This Portfolio: (Home, About, Skills, Portfolio, Services, Blog, Team, Contact)

## You Can Download My CV using "Download CV" button

## You Can Directly Contact Me on WhatsApp using The WhatsApp Button

### Here I used "Owl Carousel" for Carousel in the Team Section. 

### For Scroll Animation, I used "ScrollReveal"

<img src="./image/Complete Website.png">

