# Responsive and AutoPlay Swiper Slider in HTML, CSS and JavaScript 

## Watch the video without any skip. Hope you will understand all about Swiper JS.

<img src="./images/swiper js.PNG">